<?php
    session_start();
    include "../model/api.php";
    alarmon();
?>