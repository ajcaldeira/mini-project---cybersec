import cam
def main():
    PIC_NAME = cam.takeSavePic()
    print(PIC_NAME)

if __name__ == "__main__":
    main()
    